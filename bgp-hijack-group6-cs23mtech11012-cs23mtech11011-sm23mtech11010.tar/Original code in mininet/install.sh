#!/bin/bash

sudo apt-get install -y quagga curl screen
sudo easy_install termcolor
